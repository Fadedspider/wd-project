document.addEventListener("DOMContentLoaded", () => {
    // Highlight the current navigation link
    const links = document.querySelectorAll("ul li a");
    links.forEach(link => {
        if (link.href === window.location.href) {
            link.classList.add("highlight");
        }
    });

    // Add a click alert for contact link
    const contactLink = document.querySelector(".contact strong");
    if (contactLink) {
        contactLink.addEventListener("click", () => {
            alert("Thank you for reaching out! We will get back to you shortly.");
        });
    }

    // Add a button to toggle the visibility of the contact information
    const contactSection = document.querySelector(".contact");
    if (contactSection) {
        const toggleButton = document.createElement("button");
        toggleButton.textContent = "Toggle Contact Info";
        toggleButton.style.marginTop = "10px";
        toggleButton.addEventListener("click", () => {
            contactSection.style.display = contactSection.style.display === "none" ? "block" : "none";
        });
        contactSection.parentElement.insertBefore(toggleButton, contactSection);
    }

    // Display a welcome message on page load
    alert("Welcome to Indian Literature Abroad! Explore the richness of Indian literature.");
});

